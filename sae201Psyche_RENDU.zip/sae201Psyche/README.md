Bonjour. Voici la version du Groupe A3_C2 de l'Âge de Psyché, partie finale de la SAE 2.01/2.02/2.05.

Afin de jouer à notre version de L'Âge de Psyché. il suffit de lancer un terminal, se positionner dans le dossier PSYCHE_equipe A3_C2/jeu , d'attibuer les droits d'execution au compilateur avec "chmod +x compileur.sh" puis executer "compileur.sh", et le jeu se lancera.

Si ce protocole ne marche pas, veuillez vous positionnez dans le dossier PSYCHE_equipe A3_C2/jeu et executer la commmande : "sed -i -e 's/\r$//' compileur.sh". puis executer "compileur.sh".